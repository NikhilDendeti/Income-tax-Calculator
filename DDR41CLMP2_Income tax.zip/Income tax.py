#This is a tax calculator according to the New Tax regime
#First user need to give the Gross amount in input 
income=int(input())
#Here i took a variable to deduct 50k from the gross amount because the government calculates by deducting 50k
discount_amount=income-50000
#Here the i took first statement
if discount_amount<=250000:
#here upto the variable amount is <=250000 there will be no tax for it.
    print("0")
 
 #Here the first condition is amount between 250000 and 500000   
condition1=(discount_amount>250000 and discount_amount<=500000)
if condition1:
#Here i dedected the variable amount with 250000 beacuse for first 250000 there will be no tax applied.
#for remaining amount I calculated 5% of that amount
    print(int((discount_amount-250000)*5/100))


#Next comming to the second condition here I deducted 500000 from the variable amount because first 250000 the tax would be 5% of that
#but for remaining we need to calculate 10% and remaining we need to calculate 5% of 250000
condition2=(discount_amount>500000 and discount_amount<=750000)
if condition2:
    print(int(((discount_amount-500000)*10/100)+(250000*5/100)))
    

#here also for 3rd condition I followed same as above here i deducted variable amount from 500000
#and I added 5% of 250000 and 10% of 250000 and for remaining amount I calculated 15% of that.
condition3=(discount_amount>750000 and discount_amount<=1000000)
if condition3:
    print(int((discount_amount-750000)*15/100+(250000*5/100)+(250000*10/100)))
    
    
#Here also same as above i added remaining amount of 20% and I added before all amounts.    
condition4=(discount_amount>1000000 and discount_amount<=1250000)
if condition4:
    print(int((discount_amount-1000000)*20/100+(250000*15/100)+(250000*10/100)+(250000*5/100)))


#Here also same as above i added remaining amount of 25% and I added before all amounts.    
condition5=(discount_amount>1250000 and discount_amount<=1500000)
if condition5:
    print(int(((discount_amount-1250000)*25/100)+(250000*20/100)+(250000*15/100)+(250000*10/100)+(250000*5/100)))
    

#This is last condition #Here also same as above i added remaining amount of 30% and I added before all amounts.
#and here if Gross amount is greater than 1500000 then we need to consider 30% of that. 
condition6=(discount_amount>1500000)
if condition6:
    print(int(((discount_amount-1500000)*30/100)+(250000*25/100)+(250000*20/100)+(250000*15/100)+(250000*10/100)+(250000*5/100)))
    #I did this Icome tax calculator by using this Logic.